# Botel
Bot created by spider also made with python
Botel is a bot that teaches hacking and programming
<h2>How to install:</h2>
<p>$ apt update && apt upgrade</p>
<p>$ apt install git</p>
<p>$ apt install python3</p>
<p>$ git clone https://github.com/spider863644/Botel</p>
<p>$ cd Botel</p>
<p>$ python3 Botel.py</p>
<h3>NOTE:</h3>
<p>Follow me on github</p>

